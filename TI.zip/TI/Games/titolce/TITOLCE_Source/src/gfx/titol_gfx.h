// Converted using ConvPNG
// This file contains all the graphics sources for easier inclusion in a project
#ifndef titol_gfx_H
#define titol_gfx_H
#include <stdint.h>

#define titol_gfx_transpcolor_index 0

extern uint8_t block_data[123];
#define block ((gfx_image_t*)block_data)
extern uint8_t block_collapse_data[123];
#define block_collapse ((gfx_image_t*)block_collapse_data)
extern uint8_t up_spike_data[123];
#define up_spike ((gfx_image_t*)up_spike_data)
extern uint8_t down_spike_data[123];
#define down_spike ((gfx_image_t*)down_spike_data)
extern uint8_t left_spike_data[123];
#define left_spike ((gfx_image_t*)left_spike_data)
extern uint8_t right_spike_data[123];
#define right_spike ((gfx_image_t*)right_spike_data)
extern uint8_t start_pipe_data[123];
#define start_pipe ((gfx_image_t*)start_pipe_data)
extern uint8_t end_pipe_data[123];
#define end_pipe ((gfx_image_t*)end_pipe_data)
extern uint8_t button_data[365];
#define button ((gfx_image_t*)button_data)
extern uint8_t button_down_data[365];
#define button_down ((gfx_image_t*)button_down_data)
extern uint8_t door_data[244];
#define door ((gfx_image_t*)door_data)
extern uint8_t jmtb02_data[4272];
#define jmtb02 ((gfx_image_t*)jmtb02_data)
extern uint8_t costume_l_2017_data[123];
#define costume_l_2017 ((gfx_image_t*)costume_l_2017_data)
extern uint8_t costume_r_2017_data[123];
#define costume_r_2017 ((gfx_image_t*)costume_r_2017_data)
extern uint8_t costume_r_dev_bday_data[123];
#define costume_r_dev_bday ((gfx_image_t*)costume_r_dev_bday_data)
extern uint8_t costume_r_earth_data[123];
#define costume_r_earth ((gfx_image_t*)costume_r_earth_data)
extern uint8_t costume_r_easter_data[123];
#define costume_r_easter ((gfx_image_t*)costume_r_easter_data)
extern uint8_t costume_r_groundhog_data[123];
#define costume_r_groundhog ((gfx_image_t*)costume_r_groundhog_data)
extern uint8_t costume_r_halloween_data[123];
#define costume_r_halloween ((gfx_image_t*)costume_r_halloween_data)
extern uint8_t costume_r_lincoln_data[123];
#define costume_r_lincoln ((gfx_image_t*)costume_r_lincoln_data)
extern uint8_t costume_r_july_4th_data[123];
#define costume_r_july_4th ((gfx_image_t*)costume_r_july_4th_data)
extern uint8_t costume_r_pi_day_data[123];
#define costume_r_pi_day ((gfx_image_t*)costume_r_pi_day_data)
extern uint8_t costume_r_player_data[123];
#define costume_r_player ((gfx_image_t*)costume_r_player_data)
extern uint8_t costume_r_santa_data[123];
#define costume_r_santa ((gfx_image_t*)costume_r_santa_data)
extern uint8_t costume_r_school_data[123];
#define costume_r_school ((gfx_image_t*)costume_r_school_data)
extern uint8_t costume_r_snow_data[123];
#define costume_r_snow ((gfx_image_t*)costume_r_snow_data)
extern uint8_t costume_r_st_patrick_data[123];
#define costume_r_st_patrick ((gfx_image_t*)costume_r_st_patrick_data)
extern uint8_t costume_r_sun_data[123];
#define costume_r_sun ((gfx_image_t*)costume_r_sun_data)
extern uint8_t costume_r_tau_day_data[123];
#define costume_r_tau_day ((gfx_image_t*)costume_r_tau_day_data)
extern uint8_t costume_r_trunks_data[123];
#define costume_r_trunks ((gfx_image_t*)costume_r_trunks_data)
extern uint8_t costume_r_turkey_data[123];
#define costume_r_turkey ((gfx_image_t*)costume_r_turkey_data)
extern uint8_t costume_r_valentine_data[123];
#define costume_r_valentine ((gfx_image_t*)costume_r_valentine_data)
extern uint8_t costume_r_walrii_data[123];
#define costume_r_walrii ((gfx_image_t*)costume_r_walrii_data)
extern uint8_t costume_r_washington_data[123];
#define costume_r_washington ((gfx_image_t*)costume_r_washington_data)
extern uint16_t titol_gfx_pal[19];

#endif
