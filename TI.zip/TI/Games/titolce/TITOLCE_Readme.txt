___                     _                               
 ||_ o _ o _ _|_|_  _  / \__ |\/ |   _     _ |          
 || ||_> |_>  |_| |(/_ \_/| ||/  |__(/_\_/(/_|          
 _                                     _                
|_| _|    _ ___|_   ___  _ o__   _o__ (_|   | _ __o_|_\/
| |(_|\_/(/_| ||_|_||(/__> || | _>|| |__||_||(_|| | |_/ 

Elephants sometimes do forget...the rest of the levels.

###############
# DISCLAIMER! #
###############

This game has been tested FURIOUSLY before release. I am not responsible for any loss of data, limb,
life, or sanity caused directly or indirectly by this game. If there are any glitches or bugs existing
in the game, report them to me as soon as possible on CodeWalrus, Cemetech, or Omnimaga (JWinslow23),
or email me at josiah12301@yahoo.com with bug reports.

#############################
# Installation Instructions #
#############################

Make sure you have the latest version of the C libraries on your TI-84+ CE. Then, transfer TITOL.8xp to
your calculator, and run it from the homescreen or through Cesium.

##########################
# This is the Only Level #
##########################

The elephant forgot the rest of the levels, but luckily he still has one left!
Help him beat it in all his metagaming glory.
Use your keen knowledge of gaming and dexterity to manhandle your way through a variety of challenges.
Get your mind out of the box for once! Take it outside for a walk, or maybe grab a bite to eat with it.

Oh, and beat the level. There's only one.

############
# Controls #
############

Arrow keys, but I am told not to tell you any more than that. The elephant says so.

###########
# Credits #
###########

* jmtb02 (John Cooney, jmtb02@gmail.com ) for making the awesome original version over on Armor Games
( http://armorgames.com/play/4309/this-is-the-only-level ),
and for being a good sport about my previous TI-84+ version
( http://www.ticalc.org/archives/files/fileinfo/466/46675.html ).
"The first games I ever wrote were on a TI-83, so this feels completely full circle and awesome to me."

* MateoConLechuga, for his general CE programming tips and optimizations, and his invaluable work on
bringing C programming to the TI-84+ CE, without which this and most other CE games would be impossible!

* Various users on CodeWalrus and Cemetech for giving me support along the way!

###################
# Version History #
###################

* v1.4 (December 30th, 2016)
Added messages upon unlocking Easter eggs, fixed assorted overflow bugs
* v1.3 (December 21st, 2016)
Fixed bugs with Stages 8 and 13, added Easter eggs
* v1.2 (December 20th, 2016)
Fixed bug with Stage 18, and fixed an annoying bug that caused random crashes
MateoConLechuga, thank you so much for pinpointing that bug in the code and helping me fix it!
* v1.1 (December 19th, 2016)
Fixed bug with Stage 27
* v1.0 (December 19th, 2016)
Initial release