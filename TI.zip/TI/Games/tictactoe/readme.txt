I'm not going to try to blow your minds, it's just Tic-Tac-Toe. But that being said, I still need to explain some things. First, this is the result of a collaborative project between NoahK, caleb1997, and PT_ on cemetech.net. Feel free to edit and re-release this, but be sure to give credit to these people.

Now, to playing the game. The opening menu asks you to choose between Player vs Player, Player vs Computer, and quitting the program. You will return to this screen after every game you play. That's pretty self-explainatory.

The Player vs Player mode is simple. "O" always goes first, and 2 players take turns placing pieces (or one player playing as both player, whatever flots your boat). Use the arrow keys to change the location of the pointer (the point in the center of the square) to the desired spot, and press Enter to place your piece. Ties are called only when the board is completey filled up, wins are called as soon as they occur.

Player vs Computer, on the other hand, offers a lot more options. Afer selecting PvC on the, you come to a menu to select the difficulty of the AI playing against you. The levels follow certain priorities of move options, and are as follows:

1-Win-Block
2-Center
3-Block Double
4-Opposite Corner
5-Random Corner
6-Random Edge
7-Random Piece

Random: 7
Trivial: 1,7
Easy: 1,5,6,7
Medium: 1,2,5,6,7
Hard:1,2,4,5,6,7
Impossible: 1,2,3,4,5,6,7 

(Thankfully I typed the AI level stuff up in the topic a few months back, I totally forgot what each level did.)

When a player is placing their piece, the pointer will start at wherever the player placed their last piece. This is a feature that was not intended, it's just the way the code worked out.

There is a large header for DCS at the beginning of the program. Please note that this is a pure BASIC program and DCS is not needed to play it, but the header includes both a 16x16 color icon and an 8x8 monochrome icon. (The monochome icon makes up the first line of the color icon) This icon took a bit of work to create.

This program was written on an 84+SE in hardware, then modified on SourceCoder to add the icon and CSE code. The program detects if it is running on a color calc and changes the way graphics are displayed accordingly by changing the screen ratio and adding colors.

Authors (Cemetech usernames):
NoahK
caleb1997
PT_

Other credits:
Cemetech (www.cemetech.net)
Tic-Tac-Toe Forum Topic (https://www.cemetech.net/forum/viewtopic.php?t=11607)
SourceCoder by KermMartian (https://www.cemetech.net/sc/)
