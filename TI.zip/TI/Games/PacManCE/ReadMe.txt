##--> Pac-Man TI84+CE <--##

###### INTRO ######
 The classic pacman game; now for the CE edition!
 Really just an example program; but fully playable.
 Enjoy!

###### INSTALL ######
 Using TI-Connect CE, send PacMan.8xp to you calculator.
 
###### PLAYING ######
 To run, select the Asm( token from the catalog.
 Then press [PGRM] and select PACMAN.
 The screen should look like this:

 Asm(pgrmPACMAN

 Press [ENTER]. Enjoy!

###### CONTROLS ######
 [2ND/ENTER] - Continue
 [ARROWS] - Move Pac-Man
 [DEL] - Pause\Quit Game
 [5] - Press this on the main screen to enable "hacked mode" for an extra map set

###### OBJECTIVE ######
 Munch on tasty pellets. Those big, flashy ones give you a
 drug NewHighString so you can eat ghosts. Sometimes fruit appears
 so that way you can feel good about yourself.

###### CREDITS ######
 (C) September 2016
 Matt "MateoConLechuga" Waltz

###### CHANGELOG ######
v1.2 - Optimized and added hacked mode
v1.1 - Added Cesium icon
v1.0 - First release

###### SOURCE ######
 Feel free to use it in any way you see fit. Go crazy.