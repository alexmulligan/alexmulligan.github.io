Thank you for downloading Battleship! Every time you run the program, it will ask you to put in all your ship coordinates, starting with the
carrier, and ending with the speedboat.
When it asks you for the column, put in A,B,C,..... I,J.
When it asks you for the row, put in a number. It will go to that letter and down the # that u put into the column from the top

When you enter your coordinates to place your ships, you are only entering the starting point. If you put in B,%, and place you battleship, and hit vertical for the choice,
it will place four dots going down the grid. These are your ships' hitpoints.

Every time you run the program, it draw a colored grid. Each horizontal line corresponds with that number. For example, 1 will be blue. The first line going
across the gris will be blue as well. 2 will be red, with a red line going across the screen.
And so on.

When you play:
Hit is a red square. Blue square is a miss.
Enjoy!

When you are done entering your coordinates, hand the calc to another player. (S)he will then enter their coordinates, then hand it to
you. Enter your guess, and it will place a red or blue square there.

When playing, press the Clear key to quit.

Have fun!