 +----------------------------------------------------------------------------+
 | -- TI-84+CSE/CE-------------- Spaze Invaders ------------- TI-84+CSE/CE -- |
 +----------------------------------------------------------------------------+

 +--------------+
 |     Info     |
 +--------------+

 Name:          Spaze Invaders
 Authors:       Hannes Edfeldt (original TI-83 version)
                James Vernon (TI-84+CSE & TI-84+CE ports)
 Version:       1.0.2
 Released:      March 2016
 Calculators:   TI-84+CSE / TI-84+CE
 Shell:         DoorsCSE v8.0 / None
 Players:       1 only


 +--------------------+
 |     What is it     |
 +--------------------+

 A TI-84+CSE / TI-84+CE version of the old Space Invaders game made in
 assembly.


 +------------------+
 |     Features     |
 +------------------+

 Direct input, full screen colour graphics, animation, 3 degrees of difficulty
 and 9 levels.


 +------------------------+
 |     How to install     |
 +------------------------+

 Send the file spaze.8xp to your calculator. On the TI-84+CSE, run the DoorsCSE
 shell and select "SPAZE". On the TI-84+CE, press [2nd], [0], select "Asm(",
 press [prgm] and select "SPAZE".


 +---------------+
 |     Story     |
 +---------------+

 Evil aliens have come to earth because they're out of hamsters on their
 planet and therefore plan to kidnap every single little hamster on
 earth. You're Harry Hamster and your mission is to save your friends
 from the malevolent aliens. You can't nuke your foe this time, use your
 laser instead. The aliens also plan to kidnap the scriptwriters and the
 director of X-Files, but don't bother about that.


 +---------------------+
 |     How to play     |
 +---------------------+

 At the title screen, select degree of difficulty with up and down and
 then press 2nd to start. Press left or right to move your ship, 2nd to
 fire lasers. Press MODE to pause the game and show your score. Press
 MATH to hide the game from your mathsteacher. Press CLEAR to quit.


 +---------------+
 |     Notes     |
 +---------------+

 Please, send bugreports and comments to: jamesv82@live.com.au


 +----------------------+
 |     Porters Note     |
 +----------------------+

 Hannes Edfeldt's TI-83 version of Spaze Invaders was the first assembly game
 I ever played, and it inspired me to learn assembly, which in turn taught me
 a lot of programming principles and I've applied across various languages over
 the years, so it seemed fitting that porting his game to the TI-84+CSE should
 be my first full TI-84+CSE release. Then with the release of the TI-84+CE, I
 felt obliged to port it over again. Thank you Hannes!


 +-------------------+
 |     Licensing     |
 +-------------------+

 This program is of course freeware and you may freely distribute it as
 long as all of the files (spaze.8xp and readme.txt) are included and not
 modified in any way.


 +--------------------+
 |     Disclaimer     |
 +--------------------+

 This program does some pretty lowlevel stuff and could therefore lock
 or reset your calculator (it shouldn't though). Make sure you don't have any
 important data on your calculator that isn't backed up before you run this
 program. I take no responsibility for whatever the use of this program
 may cause to your calculator.


 +--------------------------+
 |     Revision history     |
 +--------------------------+

 TI-83 version (by Hannes Edfeldt)
 
    Version 1.0     970601
                Initial release

    Version 1.1     970604
                Fixed the "Bill Nagel" bug

 TI-84+CSE version (by James Vernon)
 
    Version 1.0.0   March 2014
                Initial release

 TI-84+CSE / TI-84+CE versions (by James Vernon)
 
    Version 1.0.1   February 2016
                Ported to TI-84+CE
                Small optimisations
                
    Version 1.0.2   March 2016
                Fixed a bug on the TI-84+CE version with program writeback if
                  prgmSPAZE is hidden in Cesium


 +--------------------+
 |     The Coders     |
 +--------------------+

 TI-83 version
    Name:           Hannes Edfeldt
    Ticalc.org:     www.ticalc.org/archives/files/authors/4/466.html
    TI Story:       tistory.wikidot.com/hannes-edfeldt
    
 TI-84+CSE / TI-84+CE versions
    Name:           James Vernon
    Email:          jamesv82@live.com.au
    Web:            www.jvti.org


 +----------------+
 |     Credit     |
 +----------------+

 - WikiTI for the TI-84+CSE LCD driver information & TI-84+CE information.
 - Hannes Edfeldt for the TI-83 version of Spaze Invaders
 - Patrick Davidson for Calcuzap and optimisation ideas taken from its sprite routine
 - Christopher "Kerm Martian" Mitchell for DoorsCSE v8.0
 - The Cemetech & Omnimaga commmunities for their support & encouragement
 - Buckeyedude for Wabbitemu
 - MateoConLechuga for CEmu


 +----------------------------------------------------------------------------+
 | -- TI-84+CSE/CE-------------- Spaze Invaders ------------- TI-84+CSE/CE -- |
 +----------------------------------------------------------------------------+
