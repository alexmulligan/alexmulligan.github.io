Scarth v2.0
by Kerm Martian
http://www.Cemetech.net
Originally released May 17, 2006
Re-release for the TI-84+CSE March 12, 2013

Installation
-------------

To install Scarth v2.0, you must have a TI-84 Plus C Silver
Edition graphing calculator. Send four files to it using 
TI-Connect or TILP II: SCARTH.8xp, ZSCT0.8xp, ZSCT1.8xp, and
ZSCT2.8xp.  To give this program to another person, just
send the four files via a unit-to-unit link cable.

How to Play
------------
Scarth v2.0 is a scorched earth clone.  Your
tank and a tank controlled by the calculator
fight in a randomly-generated landscape, taking
turns firing missiles at one another.  For each
shot, you can set the power and angle that you
shoot at; as you lose health, your maximum
power will carry the projectile less and less
far.  To run Scarth, press [PRGM], arrow down
to Scarth, and press [ENTER] twice.  You will
be brought to the main menu, where you can
choose to Play, view the Help, or Quit the game.
If you choose Play, you will be asked which of
three terrain types you would like to use, and
then the selection will be generated.  Ingame,
the bars in the top left are yours, and the ones
in the top right belong to the calculator.  The
top bar in each set is the player's health, and
the bottom one is the current power set for
shots.  The gun barrel on each tank shows the
angle it is pointing.  To raise or lower the
power, use [up] and [down].  [<] and [>] change
the angle of the barrel.  [2nd] quits at the
game at any time, and [Enter] fires when you are
ready to take a shot.  You can tell whose turn
it is by seeing which tank has a visible gun
barrel.  When either health bar falls to zero,
the other player wins the game.

More Info
----------
Visit http://www.cemetech.net for hundreds more
downloads, a large community forum and members
who are willing to help with any calculator- or
technology-related problem or question.  You can
get the full list of Kerm Martian's calculator
programs at:

http://www.ticalc.org/archives/files/authors/60/6077.html

(c) 2006-2013 Kerm Martian & Cemetech.  All rights reserved.
Cemetech and Kerm Martian are not responsible for any
harm that may occur to property or individuals due
directly or indirectly to the use of this or any other
Cemetech program or project.