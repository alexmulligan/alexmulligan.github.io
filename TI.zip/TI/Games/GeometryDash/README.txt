﻿Geometry Dash (The Impossible Game) porté sur Ti-83 Premium CE et TI-84+CE ! C'est, on peut dire une version beta donc quelques bug peuvent survenir, n'oubliez pas d'archiver vos programmes quand vous l'utilisez donc (mais normalement il ne devrait pas y avoir de problème).


NOUVEAU :
	- les tiles de saut on été implémentés
	- correction de bugs (bug du cache sur le site etc...)

TOUCHES :
***** Dans le menu :
- MODE/SUPPR/ANNUL : permet de quitter le jeu
- </> : permet de choisir un niveau
- ENTER : lance le jeu pour le niveau sélectionné
***** Dans le jeu :
- 2ND : fait sauter le personnage
- SUPPR : fait revenir au menu
- ANNUL : quitte le jeu instantanément


N'hésitez pas à aller voir le topic de l'avancement du projet !
https://tiplanet.org/forum/viewtopic.php?f=12&t=19211
 

POUR CRÉER SON NIVEAU :
Voici les étapes à suivre :
	- Téléchargez et installez Tiled, un logiciel qui sert à créer des niveaux de jeux à partir d'un tileset
	- Créez le niveau d'un minimum de 10 tiles de hauteur et importez le tileset GD.png qui est dans l'archive ("Cartes" → "Nouveau Tileset"). Vous pourrez bien sûr changer plus tard la taille de la MAP en allant dans le menu "Cartes" → "Redimensionner la carte"
	- Quand votre niveau est terminé, exportez-le en .CSV
	- Ensuite, allez sur le site http://illusio.pe.hu/GeometryDash/index.php puis copiez-collez le contenu du fichier .CSV dans le "data" et mettez-lui un ou deux noms entre 1 et 8 caractères et une difficulté. Les espaces et les lettres sont les seuls caractères autorisés.
	- Si votre niveau a des changements de contexte, mettez-les dans le champ adapté. La syntaxe est la suite : "Pour chaque changement de contexte, vous devez seulement mettre le numéro de tile du changement. Les changements doivent être séparés par une virgule. Attention à mettre un numéro pair de changements, sinon le convertisseur ne vous autorisera pas à importer votre niveau !". Pour plus d'informations, je vous conseille d'aller jeter un oeil à cette page : http://illusio.pe.hu/GeometryDash/context.php
	- Une fois l'AppVar téléchargée, transférez-la sur votre calculatrice et... c'est tout !

N'hésitez pas à nous faire part de vos niveaux en les uploadant ! Ça pourrait en intéresser plus d'un ;)