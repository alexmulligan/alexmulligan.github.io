import os
from PIL import Image

infile = open("images.i")

if not os.path.exists("png"):
        os.mkdir("png")

x = 0
y = 0
height = 0
width = 0
enemy_power = None
label = ""
series_index = 0
filename = ""
i = None

def decode_hex(s):
        s = s.strip().upper()
        if (s[0] == "$"):
                lonyb = "0123456789ABCDEF".find(s[2])
                hinyb = "0123456789ABCDEF".find(s[1])
                return lonyb + hinyb * 16
        else:
                return int(s)

for line in infile:
        if ":" in line:
                label = line[0:line.find(":")]
                series_index = 0
                i = None
        if ".db" in line:
                data_bytes = line[line.find(".db" ) + 3:].split(",")
                if "$" in line:
                        for p in range(len(data_bytes) / 2):
                                msb = decode_hex(data_bytes[p * 2])
                                lsb = decode_hex(data_bytes[p * 2 + 1])
                                r = msb >> 3
                                g = ((msb & 7) << 3) + (lsb >> 5)
                                b = lsb & 31
                                
                                r = r << 3
                                if (r > 128):
                                        r = r + 7
                                g = g << 2
                                if (g > 128):
                                        g = g + 3
                                b = b << 3
                                if (b > 128):
                                        b = b + 7
                                if (y < height * series_index):
                                        i.putpixel((x,y), (r, g, b))
                                x = x + 1
                                if (x == width):
                                        x = 0
                                        y = y + 1
                                        if (y == height * series_index):
                                                i.save(filename)
                else:
                        if len(data_bytes) == 2:
                                if i is None:
                                        width = int(data_bytes[1]) * 2
                                        height = int(data_bytes[0]) 
                                        series_index = 1
                                        filename = "png\\" + label + "-" + str(width) + "-" + str(height)
                                        if enemy_power is not None and enemy_power > -1:
                                                filename = filename + "-" + str(enemy_power)
                                        filename = filename + ".png"
                                        print filename
                                        enemy_power = None
                                        x = 0
                                        y = 0
                                        i = Image.new("RGB", (width, height))
                                else:
                                        series_index = series_index + 1
                                        old = i
                                        i = Image.new("RGB", (width, height * series_index))
                                        i.paste(old, (0, 0))
                                        
                        if len(data_bytes) == 1:
                                enemy_power = int(data_bytes[0])