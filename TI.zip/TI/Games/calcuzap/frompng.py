import os
from PIL import Image
cse = open("images.i", "w")
ce = open("imagesce.i", "w")

def print_reg(line):
        cse.write(line)
        ce.write(line)
        
def dollarhex(i):
        result = hex(i)
        if len(result) == 4:
                return "$" + result[2:4]
        else:
                return "$0" + result[2:3]
        
def print_pixel(r, g, b):
        r = r >> 3
        g = g >> 2
        b = b >> 3
        high = (r << 3) + (g >> 3)
        low = ((g << 5) & 255) + b
        cse.write(dollarhex(high) + "," + dollarhex(low))
        ce.write(dollarhex(low) + "," + dollarhex(high))

for (dirpath, dirs, files) in os.walk("png"):
        for filename in files:
                full = os.path.join(dirpath, filename)
                if (full.upper()[-4:]) == ".PNG":
                        i = Image.open(full)
                        main = filename[0:len(filename)-4]
                        segs = main.split("-")
                        if (len(segs)) == 4:
                                print_reg(" .db " + segs[3] + "\n")
                        width = int(segs[1])
                        height = int(segs[2])
                        images = i.size[1] / height
                        print_reg(segs[0] + ":\n")
                        for ctr in range(images):
                                print_reg(" .db " + str(height) + "," + str(width / 2)+"\n")
                                for y in range(height):
                                        for x in range(width):
                                                if x == 0:
                                                        print_reg(" .db ")
                                                else:
                                                        print_reg(",")
                                                rgb = i.getpixel((x, y + ctr * height))
                                                print_pixel(rgb[0], rgb[1], rgb[2])
                                        print_reg("\n")
                        if segs[0] == "img_enemy_explode":
                                print_reg(" .db -1\n")
                        print_reg("\n")