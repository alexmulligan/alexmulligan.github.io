BTetris			By TI-Freakware				Version 1.0
1.	Installation
2.	Playing this game
3.	Credits

1.	Installation

Simply drag BTETRIS.8xp from the RAM folder to your favorite linking program (TILP2 or TI-Connect) or to your favorite emulator to install. Please note, this file is for the color 84+ Silver Edition only, and will not work on the black and white 84+ calculators.

2.	Playing this game

This game is simple, and follows similar button configurations that other calculator Tetris games follow. Left and right move your piece left and right. 2nd and Alpha buttons rotate the terminoes. Enter pauses the game, and Mode exits. The game is already going as fast as it can, so pressing the down button does not drop the pieces faster. This game was made completely in BASIC, though it utilizes Doors CSE�s icon ability to be easily spotted among your list of games and programs from inside Doors CSE�s desktop. (For more information, check http://dcs.cemetech.net )

When you achieve a new high score, use the up and down arrows to change characters, 2nd to ove to the next character, Del to delete the previous character, and Enter to finish the entry.

3.	Credits

Credit goes to KermMartian, tr1p1ea, merthsoft and other Cemetech and Omnimaga members for your encouragement and feedback on this project.

This project was started for the sole basis of expanding my programming abilities, as I had never tried programming an arcade game like this before.

It was started on September 11, 2013 and released as version 0.9 on October 30, 2013.

If you like this game, please make sure you download TetricA, the assembly tetris game made for your color 84+CSE.
