// Converted using ConvPNG
// This file contains all the graphics sources for easier inclusion in a project
#ifndef sprites_gfx_H
#define sprites_gfx_H
#include <stdint.h>

extern uint8_t background_data[2555];
#define background ((gfx_image_t*)background_data)
extern uint8_t bird0_data[206];
#define bird0 ((gfx_image_t*)bird0_data)
extern uint8_t bird1_data[206];
#define bird1 ((gfx_image_t*)bird1_data)
extern uint8_t bird2_data[206];
#define bird2 ((gfx_image_t*)bird2_data)
extern uint8_t ground_data[149];
#define ground ((gfx_image_t*)ground_data)
extern uint8_t pipe_i_data[98];
#define pipe_i ((gfx_image_t*)pipe_i_data)
extern uint8_t pipe_l_data[314];
#define pipe_l ((gfx_image_t*)pipe_l_data)
extern uint8_t pipe_u_data[314];
#define pipe_u ((gfx_image_t*)pipe_u_data)
extern uint16_t sprites_gfx_pal[23];

#endif
