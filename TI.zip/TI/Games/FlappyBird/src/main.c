/* Keep these headers */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <tice.h>

/* Standard headers - it's recommended to leave them included */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Shared libraries */
#include <lib\ce\graphx.h>
#include <lib/ce/fileioc.h>
#include <lib/ce/keypadc.h>
#include "gfx\sprites_gfx.h"

#define gfx_buff (*(uint8_t**)(0xE30014))
#define x_pos 100
#define NUM_PIPES 3

uint24_t score, hscore = 0;
float y_pos = 75.0, velocityY, gravity = 0.5;
uint8_t x_ground, bird_num = 0;
int pipe[NUM_PIPES][2]; //First = pipeNumber, Second = Xpos, Ypos.
uint8_t *bird[3] = {bird1_data, bird2_data, bird0_data};

/* function prototypes */
void update();
void render();
void menu();

/* Put all your code here */
void main(void) {
	ti_var_t file;
	int8_t loop = 1, i;
	srand(rtc_Time());
	
	ti_CloseAll();
	file = ti_Open("FLAPPYB", "r+");
	if(file)ti_Read(&hscore, sizeof(uint24_t), sizeof(hscore)/sizeof(uint24_t), file);
	
	gfx_Begin(gfx_8bpp);
	gfx_SetPalette(sprites_gfx_pal, sizeof sprites_gfx_pal, 0);
	gfx_SetTextBGColor(0x00);
	gfx_SetTextTransparentColor(0x00);
	gfx_SetTextFGColor(0x06);
	gfx_SetDrawBuffer();
	
	for(i = 0; i < NUM_PIPES; i++){
		pipe[i][0] = 45+344/3*i;pipe[i][1] = 24+rand()%95;
	}
	
	menu();
	
	while (kb_ScanGroup(kb_group_6) != kb_Clear) {
		if(kb_AnyKey() && loop>5){
			velocityY = -5.0;loop=0;
		}
		update();
		render();
		loop = (loop>5?6:loop+1);
	}
	
	ti_CloseAll();
	file = ti_Open("FLAPPYB", "w");
	if(file)ti_Write(&hscore, sizeof(uint24_t), sizeof(hscore)/sizeof(uint24_t), file);
	
	gfx_End();
    pgrm_CleanUp();
}

void update(){
	uint8_t i;
	velocityY += gravity;
    y_pos += velocityY;
	x_ground = ((x_ground+3)%21==0?0:x_ground+3);
	bird_num = ((bird_num+1)%9==0?0:bird_num+1);
	/* bird hit the ground */
    if(y_pos > 178.0) {
		y_pos = 176.0;
		menu();
	}
	for(i=0;i<NUM_PIPES;i++){
		pipe[i][0] -= 3;
		if(x_pos+17>=pipe[i][0]&&x_pos<=pipe[i][0]+24&&(y_pos<pipe[i][1]||y_pos+12>pipe[i][1]+45)){
			if(x_pos+13>=pipe[i][0]&&x_pos<=pipe[i][0]+16){
				if(y_pos<pipe[i][1])
					y_pos = pipe[i][1];
				if(y_pos+12>pipe[i][1]+45)
					y_pos = pipe[i][1]+33;
			}
			menu();
		}
		if(pipe[i][0] <= -24){
			pipe[i][0] = 320;pipe[i][1] = 24+rand()%95;
		}
		if(pipe[i][0]==74)score++;
	}
}

void render(){
	uint24_t i, j;
	/* Draw background */
	memset_fast(gfx_buff, 0x04, 320*142);
	for(i=0; i<271; i+=37)gfx_Sprite(background, i, 142);
	memset_fast(&(*gfx_buff)+179*320, 0x07, 320*9);
	/* Draw pipes */
	for(j=0;j<NUM_PIPES;j++)if(pipe[j][0]<=320){
		for(i=0;i<187;i+=4)if(i<pipe[j][1]-10||i>pipe[j][1]+48)gfx_Sprite(pipe_i, pipe[j][0], i);
		gfx_Sprite(pipe_u, pipe[j][0] - 1, pipe[j][1] - 12);
		gfx_Sprite(pipe_l, pipe[j][0] - 1, pipe[j][1] + 45);
	}
	/* Draw ground */
	for(i=0; i<321; i+=21)gfx_Sprite(ground, i-x_ground, 188);
	memset_fast(&(*gfx_buff)+195*320, 0x16, 320*45);
	/* Draw bird */
	if(y_pos>-10)
		gfx_TransparentSprite(((gfx_image_t*) bird[bird_num / 3]), x_pos, y_pos);
	/* Draw Score */
	gfx_SetTextXY(148, 40);
	gfx_PrintUInt(score, 3);
	gfx_SwapDraw();
}

void draw_menu(){
	gfx_SetDrawScreen();
	gfx_SetColor(0x06);gfx_FillRectangle(126, 40, 68, 108);
	gfx_SetColor(0x16);gfx_FillRectangle(128, 42, 64, 104);
	gfx_SetColor(0x13);gfx_FillRectangle(132, 46, 56, 96);
	gfx_SetColor(0x16);gfx_FillRectangle(134, 48, 52, 92);
	gfx_PrintStringXY("SCORE", 140, 59);
	gfx_SetTextXY(148, 73);gfx_PrintUInt(score, 3);
	gfx_PrintStringXY("BEST", 144, 99);
	gfx_SetTextXY(148, 111);gfx_PrintUInt(hscore, 3);
	gfx_PrintStringXY("Press any key to start", 84, 210);
	gfx_PrintStringXY("BY RICO", 135, 230);
	gfx_SetDrawBuffer();
}

void menu(){
	int8_t key = 0, i;
	if(score>hscore)hscore=score;
	render();
	draw_menu();
	boot_WaitShort();
	while (!key) {key = os_GetCSC();}
	for(i = 0; i < NUM_PIPES; i++){
		pipe[i][0] = 320+344/3*i;pipe[i][1] = 24+rand()%95;
	}
	score = 0;velocityY = -1;y_pos = 75.0;
}
