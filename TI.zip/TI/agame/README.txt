This program is a modified version of Cesium, called AGAME that does not let the user transfer games to other calculators. It also provides a passcode feature to Cesium. Please note that someone with strong calculator knowledge may be able to get around these features, so CesiumDRM is reccomended for teachers to use on students. Most students will not know how to circumvent the restrictions.
CESIUM is a slim shell and launcher program that has support for running programs regardless of archive status, an organized and colorful GUI, and, most importantly, includes support for relocatable C and ASM libraries for use in other programs. Hide programs, lock BASIC programs from editing, and more with Cesium. Enjoy!
Regular Cesium will not work with this program, as this program has a modified version of Cesium for use as security measures.

Setup:
1. Install all the files onto the TI-84 Plus CE.
2. Launch the "A" program. Cesium should install itself.
3. Run Asm(prgmAGSETUP
4. Open A again, and Cesium should open. The calculator is now "activated" for Cesium
5. (Optional) Open prgmAGPASSCODE and set a passcode following the onscreen instructions.
6. (Optional) Open Cesium and hide all programs except for: AGSETUP and CESIUM

Transferring instructions:
1. Make sure your calculator has the AGSETUP program on it.
2. Open Cesium and unhide all programs you wish to transfer
3. Link your calculator to the new calculator.
4. Transfer all the files you want to transfer, plus A, AGPASSCODE, and AGSETUP, as well as Cesium.
5. Follow instructions 2-6 from Setup on the new calculator.
6. On the new calculator, delete AGSETUP. This will prevent the new calculator from being able to transmit the launcher, as they need it to unlock Cesium.

Please note that MateoConLechuga is not responsible legally for this program, he provided Cesium, which was modified by KingInfinity and Runer112 to fit the needs of AGAME.